from socket import *
import re
import threading

global IP_ADDR 
IP_ADDR = "127.0.0.1"
global PORT 
PORT= 13000

global LOCAL_SERVER_IP
LOCAL_SERVER_IP = "127.0.0.1"
global LOCAL_SERVER_PORT
LOCAL_SERVER_PORT = 12000

ADDR = (IP_ADDR,PORT)

LIST_LINKS_WHICH_USERS_VISITED = {}

LIST_USER_LINK_HISTORY = {}

BLACKLIST = [
    "moviedownload.com",
    "piratedmovie.com",
    "freemovie.com"
]

KEYWORD = [
    "free download",
    "Free download",
    "pirated",
    "Pirated",
    "lottery",
    "Lottery"
]

print("Proxy server test listening on ", ADDR)

# Create a TCP socket
# Notice the use of SOCK_STREAM for TCP packets
proxyServerSocket = socket(AF_INET, SOCK_STREAM)
proxyServerSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
# Assign IP address and port number to socket
proxyServerSocket.bind(ADDR)
proxyServerSocket.listen(100)
    
try:  

    def fnConnectClients(clientSocket,clientAddr):

        try:  

            # Receive the client packet along with the address it is coming from
            message = clientSocket.recv(104857)

            # If there is no message available then break out of the loop
            if not message : 
                return 

            Host = None
            # check what file client want to request using regular expression
            m = re.search('Host: (.)+(:[0-9]{1,5})?', message.decode())
            Host = m.group(0)[6:-1]


            serverUrl = re.search('^GET \/[a-zA-Z0-9\.%\/:]{1,} ', message.decode("utf-8"))
            try:
                serverUrl = serverUrl.group(0)
            except Exception as e:
                serverUrl =""
                
            global PORT
            global IP_ADDR
            global LOCAL_SERVER_IP
            global LOCAL_SERVER_PORT

            if(Host[:15] == str(IP_ADDR+":"+str(PORT)) and serverUrl[5:20] != str(LOCAL_SERVER_IP+":"+str(LOCAL_SERVER_PORT))):

                message = f"""GET /favicon.ico HTTP/1.0\nConnection: close\nHost: localhost\n""" 
                message  =  message.encode('utf-8')

                Host = str(LOCAL_SERVER_IP+":"+str(LOCAL_SERVER_PORT))


            if(serverUrl[5:20] == (LOCAL_SERVER_IP+":"+str(LOCAL_SERVER_PORT))):

                path = re.search(LOCAL_SERVER_IP+':'+str(LOCAL_SERVER_PORT)+'\/[a-zA-Z0-9\/\.%]{1,} HTTP', message.decode("utf-8"))

                try:
                    print("ADDR ",clientAddr,"----------------------------------------------------")
                    path = path.group(0)
                    path = path[15:-5]
                    print("ADDR ",clientAddr," path ",path)
                except Exception as e:
                    print("ADDR ",clientAddr,e)
                    print("Error ADDR ",clientAddr,"message\n",message.decode('utf-8'))

                message = f"""GET {path} HTTP/1.0\nConnection: close\nHost: localhost\n""" 
                message  =  message.encode('utf-8')

                Host = (LOCAL_SERVER_IP+":"+str(LOCAL_SERVER_PORT))

                if(Host[-3:]!= "443" ):
                    print("ADDR ",clientAddr," Client want request of ",Host)




                try:
                    IP_ADDR_SERVER, PORT =  Host.split(':')
                    ADDR = (IP_ADDR_SERVER,int(PORT))
                except ValueError as e:
                    IP_ADDR_SERVER = Host.replace("\r","")
                    ADDR = (IP_ADDR_SERVER,80)

            # TODO        LIST_USER_LINK_HISTORY[clientAddr[0]] =[] 
                    LIST_USER_LINK_HISTORY[clientAddr[0]].append(IP_ADDR_SERVER)

                    LIST_LINKS_WHICH_USERS_VISITED[IP_ADDR_SERVER] = []
                    LIST_LINKS_WHICH_USERS_VISITED[IP_ADDR_SERVER].append(clientAddr[0])


                
                
                if (IP_ADDR_SERVER in BLACKLIST):

                    file = open("blacklist.html", "rb")
                    payload = file.read()

                    payload = payload.decode("utf-8")

                    payload_size = len(payload)

                    payload = "HTTP/1.1 200 OK\r\n" \
                    +"Date: Sun, 22 Oct 2023 19:27:32 GMT\r\n" \
                    +"Server:Created by Manan\r\n" \
                    +"Last-Modified:Sat, 06 Oct 2018 08:00:43 GMT\r\n" \
                    +"ETag: \"140c-5778ac8ef5adc\"\r\n" \
                    +"Accept-Ranges: bytes\r\n" \
                    +"Content-Length:"+ str(payload_size) +"\r\n" \
                    +"Connection: close\r\n" \
                    +"Cache-Control: no-store, no-cache, must-revalidate\r\n" \
                    +"Content-Type: text/html\r\n\n" \
                    +payload

                    clientSocket.sendall(payload.encode('utf-8'))

                    clientSocket.close()

                    pass

                    print("after Pass")


                
                
                # establish the TCP socket connection
                serverSocket = socket(AF_INET,SOCK_STREAM)

                # connect client to the server with the specified IP address and port

                try:
                    serverSocket.connect(ADDR)
                # send the client message to the server
                except Exception as e:
                    print("ADDR ",clientAddr," error ",e)
                serverSocket.sendall(message)


                payload = None


                # this while loop is for getting the response from the server and after sending and retransmitting
                while True:

                    # try block for if packet is not received then handle the error
                    try:

                        while True:

                            payload = serverSocket.recv(104857)

                            if not payload:
                                break

                            try:
                
                                payload = payload.decode('utf8')
                                for i in KEYWORD:
                                    payload = payload.replace(i,"*"*len(i))

                                clientSocket.sendall(payload.encode("utf-8"))

                            except UnicodeDecodeError:
                                clientSocket.sendall(payload)

                            if(Host[-3:]!= "443" ):
                                print("ADDR ",clientAddr," Client request of ",Host," is successfully completed")

                        clientSocket.close()

                        # Close the server connection
                        serverSocket.close()

                        # break is for because we know that we don't need for retransmission
                        break
                    
                    # timeout error is for if we don't receive the response from the server within time second
                    except timeout:
                        if(Host[-3:]!= "443" ):
                            print("Timeout occurred for Host ",Host)
                        pass

        except ConnectionResetError as e:
            if(Host[-3:]!= "443" ):
                print("Connection reset for Host ",Host)

    while True:

        # Accept a connection from a client
        clientSocket,clientAddr = proxyServerSocket.accept()

        # Create a thread to handle the multiple connection
        thread = threading.Thread(target=fnConnectClients,args=(clientSocket,clientAddr))

        # start the tread using start function   
        thread.start()

except KeyboardInterrupt:
    proxyServerSocket.close()
    print("KeyboardInterrupt occurred socket shutdown")
    print(LIST_LINKS_WHICH_USERS_VISITED)
    print(LIST_USER_LINK_HISTORY)