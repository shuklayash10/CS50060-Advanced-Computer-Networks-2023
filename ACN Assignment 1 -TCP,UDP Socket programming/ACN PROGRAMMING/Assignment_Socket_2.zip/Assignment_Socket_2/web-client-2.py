from socket import *
from enum import Enum
import re

# server ip address
IP_ADDR = "127.0.0.1"
PORT = 12000
ADDR = (IP_ADDR,PORT)

# Enum for type of data to be sent
class TYPE(Enum):
    HTML = 1
    IMG = 2
    LINK = 3


class HTTP():

    ADDR =None
    clientSocket = None

    
    def __init__(self,ADDR):

        self.ADDR = ADDR

        # establish the TCP socket connection
        self.clientSocket = socket(AF_INET,SOCK_STREAM)

        # connect client to the server with the specified IP address and port
        self.clientSocket.connect(self.ADDR)




    def GET_request(self,format):

        # send packet to server with sendall function because the sendall function is good for error handling
        self.clientSocket.sendall(format.encode("utf-8"))

        # set timeout to 1 second for request timeout 
        self.clientSocket.settimeout(1)

        type = TYPE.HTML

        self.GET_response(type)


    def GET_response(self,type):

        # declare the data which captures server response
        data = None

        # this while loop is for getting the response from the server and after sending and retransmitting
        while True:

            # try block for if packet is not received then handle the error
            try:

                data = self.clientSocket.recv(104857600) # 100*2^20Byte = 100MB message size

                # break is for because we know that we don't need for retransmission
                break
            
            # timeout error is for if we don't receive the response from the server within time second
            except timeout:
                pass

        print(data.decode('utf-8'))

    
    def send_request(self,url):

        # print(type(url))

        regex = r'^([0-9]{1,3}\.){3}([0-9]{1,3}):([0-9]{1,}\/home\.html)$'
        
        match = re.search(regex, url)

        if match:

            http_structure = """GET /home.html HTTP/1.1\nConnection: close\nHost: 127.0.0.1:80\nAccept: text/html\n"""

            self.GET_request(http_structure)

        else:
            print('No main website URL found in the given text.')


# This is random message generation for payload
def payload():
    # print("Link: ",f"{IP_ADDR}:{PORT}/home.html")
    return f"{IP_ADDR}:{PORT}/home.html"

httpObj = HTTP(ADDR)

httpObj.send_request(payload())




