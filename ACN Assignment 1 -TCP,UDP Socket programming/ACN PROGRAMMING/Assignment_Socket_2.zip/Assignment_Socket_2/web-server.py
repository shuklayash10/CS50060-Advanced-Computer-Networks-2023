from socket import *
import re
from enum import Enum
import threading

IP_ADDR = "127.0.0.1"
PORT = 12000
ADDR = (IP_ADDR,PORT)


class TYPE(Enum):
    FILE = 1
    IMG = 2


serverSocket = None

try:

    # Create a TCP socket
    # Notice the use of SOCK_STREAM for TCP packets
    serverSocket = socket(AF_INET, SOCK_STREAM)

    # Create Port reusable socket
    serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)

    # Assign IP address and port number to socket
    serverSocket.bind(ADDR)
    # Listen for 5 connections
    serverSocket.listen(100)

        
    def fileHandler_local(fileName):

        fT = fileName[-1]


        if fT == "l" or fT == "/"  : fileType = "text/html"
        elif fT == "s" : fileType = "text/css"
        elif fT == "g" : fileType = "image/jpg"
        elif fT == "f" : fileType = "image/gif"
        elif fT == "o" : fileType = "image./x-icon"


        # print("fileType: ",fileType)

        # this is for index html file and root directory
        if(fileName == "/index.html" or fileName =="/"):
            file = open("index.html", "rb")

        elif (fileName == "/keyword.html" or fileName =="/"):
            file = open("keyword.html", "rb")
        
        elif(fileName == "/style.css"):
            file = open("style.css", "rb")

        elif(fileName[0:7] == "/images"):
            file = open(fileName[1:], "rb")

        elif(fileName == "/favicon.ico"):
            file = open("favicon.ico", "rb")
        else:
            file = open("404.html", "rb")

        # Read the html file
        payload = file.read() 

        # close the file manager
        file.close()

        payload_size = len(payload)


        if fT == "l" or fT == "s":
            payload = payload.decode("utf-8")
            payload = "HTTP/1.0 200 OK\r\n" \
            +"Date: Sun, 22 Oct 2023 19:27:32 GMT\r\n" \
            +"Server:Created by Manan\r\n" \
            +"Last-Modified:Sat, 06 Oct 2018 08:00:43 GMT\r\n" \
            +"ETag: \"140c-5778ac8ef5adc\"\r\n" \
            +"Accept-Ranges: bytes\r\n" \
            +"Content-Length:"+ str(payload_size) +"\r\n" \
            +"Connection: close\r\n" \
            +"Cache-Control: no-store, no-cache, must-revalidate\r\n" \
            +"Content-Type: "+fileType+"\r\n\n" \
            +payload
            return (TYPE.FILE,payload)
        
        else: 

            payload_header = "HTTP/1.0 200 OK\r\n" \
            +"Date: Sun, 22 Oct 2023 19:27:32 GMT\r\n" \
            +"Server:Created by Manan\r\n" \
            +"Last-Modified:Sat, 06 Oct 2018 08:00:43 GMT\r\n" \
            +"ETag: \"140c-5778ac8ef5adc\"\r\n" \
            +"Accept-Ranges: bytes\r\n" \
            +"Cache-Control: no-store, no-cache, must-revalidate\r\n" \
            +"Content-Length:"+ str(payload_size) +"\r\n" \
            +"Connection: close\r\n" \
            +"Content-Type: "+fileType+"\r\n\n"

            return (TYPE.IMG,(payload_header,payload))




    def HandleRequest(clientSocket,clientAddr):
                
        print("connection: ",clientAddr)


        # get GET request from clients
        message = clientSocket.recv(104857)

        # check what file client want to request using regular expression
        m = re.search('^GET \/[a-zA-Z0-9\.%\/]{1,}', message.decode("utf-8"))
        if m:
            found = m.group(0)

        # remove first 4 character which are GET[ ] bracket show the space
        try:
            fileName = found[4:]
        except Exception:
            fileName= '/'


        # info_payload is used for get payload along with information
        info_Payload = fileHandler_local(fileName)

        # check file type to send payload according to client
        if info_Payload[0] == TYPE.FILE:
            #send the payload to the client
            clientSocket.sendall(info_Payload[1].encode("utf-8"))
        
        else:
            clientSocket.sendall(info_Payload[1][0].encode("utf-8"))
            clientSocket.sendall(info_Payload[1][1])


        # Close the client connection
        clientSocket.close()



    print("PORT: ",ADDR)


    while True:

            # Accept a connection from a client
            clientSocket,clientAddr = serverSocket.accept()

            # Create a thread to handle the multiple connection
            thread = threading.Thread(target=HandleRequest,args=(clientSocket,clientAddr))

            # start the tread using start function   
            thread.start()


    
except Exception as e:

    print(e)
    serverSocket.close()
    print("KeyboardInterrupt occurred socket shutdown")

