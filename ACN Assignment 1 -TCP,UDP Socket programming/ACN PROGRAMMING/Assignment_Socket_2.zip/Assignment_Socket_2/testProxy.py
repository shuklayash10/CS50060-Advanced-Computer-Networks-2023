from socket import *
import random
import time

# server ip address
IP_ADDR = "captive.apple.com"
PORT = 80
ADDR = (gethostbyname(IP_ADDR),PORT)


# establish the TCP socket connection
clientSocket = socket(AF_INET,SOCK_STREAM)

# connect client to the server with the specified IP address and port
clientSocket.connect(ADDR)


# add payload for packet using rMsg() function
payload =  """GET / HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: en-US,en;q=0.9
Connection: close
Host: captive.apple.com
Upgrade-Insecure-Requests: 1
"""

# send packet to server with sendall function because the sendall function is good for error handling
clientSocket.sendall(payload.encode())

# declare the data which captures server response
data = None


# try block for if packet is not received then handle the error
data = clientSocket.recv(10240)


# print the server payload, packet number and RTT
print(data.decode("utf-8"))

# close the TCP connection
clientSocket.close()

