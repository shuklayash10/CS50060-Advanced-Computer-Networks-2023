from socket import *
from enum import Enum
import re

# server ip address
IP_ADDR = "127.0.0.1"
PORT = 12000
ADDR = (IP_ADDR,PORT)

# Enum for type of data to be sent
class TYPE(Enum):
    HTML = 1
    IMG = 2
    LINK = 3


class HTTP():

    ADDR =None
    clientSocket = None

    
    def __init__(self,ADDR):

        self.ADDR = ADDR

        # establish the TCP socket connection
        self.clientSocket = socket(AF_INET,SOCK_STREAM)

        # connect client to the server with the specified IP address and port
        self.clientSocket.connect(self.ADDR)




    def GET_request(self,format):

        # send packet to server with sendall function because the sendall function is good for error handling
        self.clientSocket.sendall(format.encode("utf-8"))

        # set timeout to 1 second for request timeout 
        self.clientSocket.settimeout(1)

        return self.GET_response(type)


    def GET_response(self,type):

        # declare the data which captures server response
        data = None

        # this while loop is for getting the response from the server and after sending and retransmitting
        while True:

            # try block for if packet is not received then handle the error
            try:

                data = self.clientSocket.recv(104857600) # 100*2^20Byte = 100MB message size

                # break is for because we know that we don't need for retransmission
                break
            
            # timeout error is for if we don't receive the response from the server within time second
            except timeout:
                pass
      
        return data
	
    def send_request(self,url):

        # print(type(url))

        html_regex = r'^([0-9]{1,3}\.){3}([0-9]{1,3}):([0-9]{1,}\/index\.html)$'
        css_regex = r'^([0-9]{1,3}\.){3}([0-9]{1,3}):([0-9]{1,}\/style\.css)$'
        image1_regex = r'^([0-9]{1,3}\.){3}([0-9]{1,3}):([0-9]{1,}\/images\/sachin\.png)$'
        image2_regex = r'^([0-9]{1,3}\.){3}([0-9]{1,3}):([0-9]{1,}\/images\/msd\.jpg)$'
        image3_regex = r'^([0-9]{1,3}\.){3}([0-9]{1,3}):([0-9]{1,}\/images\/virat\.jpg)$'
                
        html_match = re.search(html_regex, url)
        css_match = re.search(css_regex, url)
        image1_match = re.search(image1_regex, url)
        image2_match = re.search(image2_regex, url)
        image3_match = re.search(image3_regex, url)
        
        object_path = url[len(IP_ADDR+":"+str(PORT)):]

        if html_match or css_match or image1_match or image2_match or image3_match:

            http_structure = f"""GET {object_path} HTTP/1.1\nConnection: close\nHost: localhost\nAccept: text/html\n"""

            return self.GET_request(http_structure)

        else:
            print('No main website URL found in the given text.')


# This is random message generation for payload
def payload():
    # print("Link: ",f"{IP_ADDR}:{PORT}/home.html")
    return f"{IP_ADDR}:{PORT}/index.html"
    
def extract_referenced_objects(data):
        
        href_regex = r'href=["\'](.*?)["\']'
	
        href_references = re.findall(href_regex, data)
	
        print("Link references: ",href_references)
    
        src_regex = r'src=["\'](.*?)["\']'
    	
        src_references = re.findall(src_regex, data)
	
        print("Image references: ",src_references)
        
        for obj in href_references:

            httpObj = HTTP(ADDR)
            
            data = httpObj.send_request(f"{IP_ADDR}:{PORT}/{obj}")
            
            print(data.decode('utf-8'))
            
        for obj in src_references:
            httpObj = HTTP(ADDR)
            print(f"\n\n{obj}\n\n")
            data =  httpObj.send_request(f"{IP_ADDR}:{PORT}/{obj}")
            image_start = data.index(b"\r\n\n")+3
            print(data[:image_start].decode('utf-8'))
            print(data[image_start:])
            
            
httpObj = HTTP(ADDR)

data = httpObj.send_request(payload())

print(data.decode('utf-8'))

extract_referenced_objects(data.decode('utf-8'))
