
hostName ="wewe.fgofg:333"

ADDR = hostName.split(":")

print(ADDR)