from socket import *
import re
import threading

IP_ADDR = "127.0.0.1"
PORT = 13000

ADDR = (IP_ADDR,PORT)

print("Proxy server test listening on ", ADDR)

# Create a TCP socket
# Notice the use of SOCK_STREAM for TCP packets
proxyServerSocket = socket(AF_INET, SOCK_STREAM)
proxyServerSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
# Assign IP address and port number to socket
proxyServerSocket.bind(ADDR)
proxyServerSocket.listen(100)
    
try:  

    def fnConnectClients(clientSocket,clientAddr):

        try:  

            # Receive the client packet along with the address it is coming from
            message = clientSocket.recv(104857)

            # If there is no message available then break out of the loop
            if not message : 
                return 

            Host = None
            # check what file client want to request using regular expression
            m = re.search('Host: (.)+(:[0-9]{1,5})?', message.decode())
            Host = m.group(0)[6:-1]


            serverUrl = re.search('^GET \/[a-zA-Z0-9\.%\/:]{1,} ', message.decode("utf-8"))
            try:
                serverUrl = serverUrl.group(0)
            except Exception as e:
                serverUrl =""
                

            if(Host[:15] == "127.0.0.1:13000" and serverUrl[5:20] != "127.0.0.1:12000"):

                message = f"""GET /favicon.ico HTTP/1.0\nConnection: close\nHost: localhost\n""" 
                message  =  message.encode('utf-8')

                Host = "127.0.0.1:12000"


            if(serverUrl[5:20] == "127.0.0.1:12000"):

                path = re.search('127.0.0.1:12000\/[a-zA-Z0-9\/\.%]{1,} HTTP', message.decode("utf-8"))

                try:
                    print("ADDR ",clientAddr,"----------------------------------------------------")
                    path = path.group(0)
                    path = path[15:-5]
                    print("ADDR ",clientAddr," path ",path)
                except Exception as e:
                    print("ADDR ",clientAddr,e)
                    print("Error ADDR ",clientAddr,"message\n",message.decode('utf-8'))

                message = f"""GET {path} HTTP/1.0\nConnection: close\nHost: localhost\n""" 
                message  =  message.encode('utf-8')

                Host = "127.0.0.1:12000"

            if(Host[-3:]!= "443" ):
                print("ADDR ",clientAddr," Client want request of ",Host)


            try:
                IP_ADDR, PORT =  Host.split(':')
                ADDR = (IP_ADDR,int(PORT))
            except ValueError as e:
                ADDR = (Host.replace("\r",""),80)

            
            
            # establish the TCP socket connection
            serverSocket = socket(AF_INET,SOCK_STREAM)

            # connect client to the server with the specified IP address and port

            try:
                serverSocket.connect(ADDR)
            # send the client message to the server
            except Exception as e:
                print("ADDR ",clientAddr," error ",e)
            serverSocket.sendall(message)


            payload = None


            # this while loop is for getting the response from the server and after sending and retransmitting
            while True:

                # try block for if packet is not received then handle the error
                try:

                    while True:

                        payload = serverSocket.recv(104857)

                        if not payload:
                            break

                        print("ADDR ",ADDR, "payload Size ",len(payload))

                        clientSocket.sendall(payload)

                        if(Host[-3:]!= "443" ):
                            print("ADDR ",clientAddr," Client request of ",Host," is successfully completed")

                    clientSocket.close()

                    # Close the server connection
                    serverSocket.close()

                    # break is for because we know that we don't need for retransmission
                    break
                
                # timeout error is for if we don't receive the response from the server within time second
                except timeout:
                    if(Host[-3:]!= "443" ):
                        print("Timeout occurred for Host ",Host)
                    pass

        except ConnectionResetError as e:
            if(Host[-3:]!= "443" ):
                print("Connection reset for Host ",Host)

    while True:

        # Accept a connection from a client
        clientSocket,clientAddr = proxyServerSocket.accept()

        # Create a thread to handle the multiple connection
        thread = threading.Thread(target=fnConnectClients,args=(clientSocket,clientAddr))

        # start the tread using start function   
        thread.start()

except KeyboardInterrupt:
    proxyServerSocket.close()
    print("KeyboardInterrupt occurred socket shutdown")